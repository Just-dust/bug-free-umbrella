﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
        public Form1()
        {
            InitializeComponent();
        }

        private void заказчикBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказчикBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Мирошниченко_419_8DataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Заказы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказчик". При необходимости она может быть перемещена или удалена.
            this.заказчикTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Заказчик);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("select Пароль from Пользователи where Логин = @log", conn);
            SqlCommand com2 = new SqlCommand("select Роль from Пользователи where Логин = @log", conn);
            SqlCommand com3 = new SqlCommand("select ID_пользователя from Пользователи where Логин = @log;", conn);

            SqlParameter p1 = new SqlParameter("@log", textBox1.Text);
            SqlParameter p2 = new SqlParameter("@log", textBox1.Text);
            SqlParameter p3 = new SqlParameter("@log", textBox1.Text);

            com.Parameters.Add(p1);
            com2.Parameters.Add(p2);
            com3.Parameters.Add(p3);
            conn.Open();
            
            if (com.ExecuteScalar() == null) label6.Text = "Неверный ввод";
            if (com.ExecuteScalar() != null && com.ExecuteScalar().ToString() == textBox2.Text)
            {
                string role = com2.ExecuteScalar().ToString();
                int role_i = 0;
                if (role == "customer")
                {
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form3 f = new Form3(id);
                    f.ShowDialog();
                    this.Close();
                }
                if (role == "employee" || role == "admin")
                {
                    if (role == "employee")
                    {
                        role_i = 1;
                    }
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form4 f4 = new Form4(id, role_i);
                    f4.ShowDialog();
                    this.Close();
                }
            }
            conn.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }
    }
}
