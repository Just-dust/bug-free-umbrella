﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
        public Form2()
        {
            InitializeComponent();
        }

        private void заказыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Мирошниченко_419_8DataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Заказы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("insert into Пользователи values(@log, @pas, 'customer')", conn);
            SqlCommand com2 = new SqlCommand("select Логин from Пользователи where Логин = @log", conn);
            SqlCommand com4 = new SqlCommand("select ID_пользователя, Роль from Пользователи where Логин = @log", conn);
            SqlCommand com3 = new SqlCommand("insert into Заказчик values (@fio, @tel, @id)", conn);

            int id = 0;
            SqlParameter p = new SqlParameter("@log", textBox1.Text);
            SqlParameter p2 = new SqlParameter("@pas", textBox1.Text);
            SqlParameter p3 = new SqlParameter("@log", textBox1.Text);
            SqlParameter p4 = new SqlParameter("@fio", textBox3.Text);
            SqlParameter p5 = new SqlParameter("@tel", textBox4.Text);
            SqlParameter p6 = new SqlParameter("@log", textBox1.Text);


            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com2.Parameters.Add(p3); 
            com4.Parameters.Add(p6);
            com3.Parameters.Add(p5);
            com3.Parameters.Add(p4);


            conn.Open();
            if (!string.IsNullOrEmpty(textBox1.Text) && !string.IsNullOrEmpty(textBox2.Text) && !string.IsNullOrEmpty(textBox3.Text) && !string.IsNullOrEmpty(textBox4.Text))
            {
                if (com2.ExecuteScalar() == null)
                {
                    com.ExecuteNonQuery();
                    id = int.Parse(com4.ExecuteReader()[0].ToString());
                    SqlParameter p7 = new SqlParameter("@id", id);
                    com3.Parameters.Add(p7);
                    com3.ExecuteNonQuery();
                    label6.Text = textBox1.Text + " создан!";

                    if (com4.ExecuteReader()[1].ToString() == "customer")
                    {
                        Form3 f3 = new Form3(id);
                        f3.ShowDialog();
                        this.Close();
                    }

                }
                else label6.Text = "Такой пользователь уже существует";

            }
            else label6.Text = "Неверный ввод";
            conn.Close();
        }
    }
}
