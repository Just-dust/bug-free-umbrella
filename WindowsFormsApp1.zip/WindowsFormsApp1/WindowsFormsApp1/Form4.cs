﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
        SqlCommand com_update = new SqlCommand("select * from График_производства");
        SqlCommand com_update_customer = new SqlCommand("select * from Заказчик");
        SqlCommand com_update_order = new SqlCommand("select * from Заказы");
        SqlCommand com_update_users = new SqlCommand("select * from Пользователи");
        SqlCommand com_update_products = new SqlCommand("select * from Продукты");
        SqlCommand com_update_employee = new SqlCommand("select * from Сотрудники");
        int role_adm;

        public Form4(int id, int role_i)
        {
            int id_emp = id;
            role_adm = role_i;

            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Статусы_производства". При необходимости она может быть перемещена или удалена.
            this.статусы_производстваTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Статусы_производства);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Статусы_заказа". При необходимости она может быть перемещена или удалена.
            this.статусы_заказаTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Статусы_заказа);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Сотрудники);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Продукты". При необходимости она может быть перемещена или удалена.
            this.продуктыTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Продукты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Пользователи);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Заказы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказчик". При необходимости она может быть перемещена или удалена.
            this.заказчикTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Заказчик);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.График_производства". При необходимости она может быть перемещена или удалена.
            this.график_производстваTableAdapter.Fill(this._Мирошниченко_419_8DataSet.График_производства);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update.Connection = conn;
            SqlCommand com = new SqlCommand("delete from График_производства where ID_производства = @id", conn);
            SqlParameter p = new SqlParameter("@id", comboBox4.Text);
            com.Parameters.Add(p);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update.Connection = conn;
            SqlCommand com = new SqlCommand("select * from График_производства where ID_производства = @id;", conn);
            SqlParameter p = new SqlParameter("@id", textBox6.Text);
            com.Parameters.Add(p);
            conn.Open();
            if (string.IsNullOrEmpty(textBox6.Text))
            {
                SqlDataReader reader = com_update.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
            }
            else
            {
                bool suc = int.TryParse(textBox6.Text, out int result);
                if (suc)
                {
                    SqlDataReader reader = com.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox6.Clear();
                }
            }
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update.Connection = conn;
            SqlCommand com = new SqlCommand("insert into График_производства values (@id, @st, @en, 1)", conn);
            SqlParameter p = new SqlParameter("@id", comboBox1.Text);
            SqlParameter p2 = new SqlParameter("@st", dateTimePicker1.Value);
            SqlParameter p3 = new SqlParameter("@en", dateTimePicker2.Value);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p3);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update.Connection = conn;
            SqlCommand com = new SqlCommand("update График_производства set ID_продукта = @id_prod, Дата_начала = @st, Дата_завершения = @en, ID_статуса = @stat where ID_производства = @id", conn);
            SqlParameter p = new SqlParameter("@id_prod", comboBox2.Text);
            SqlParameter p2 = new SqlParameter("@st", dateTimePicker4.Value);
            SqlParameter p3 = new SqlParameter("@en", dateTimePicker3.Value);
            SqlParameter p4 = new SqlParameter("@stat", comboBox3.Text);
            SqlParameter p5 = new SqlParameter("@id", comboBox5.Text);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p3);
            com.Parameters.Add(p4);
            com.Parameters.Add(p5);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_customer.Connection = conn;
            SqlCommand com = new SqlCommand("select * from Заказчик where ID_заказчика = @id;", conn);
            SqlParameter p = new SqlParameter("@id", textBox1.Text);
            com.Parameters.Add(p);
            conn.Open();
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                SqlDataReader reader = com_update_customer.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView2.DataSource = dt;
            }
            else
            {
                bool suc = int.TryParse(textBox1.Text, out int result);
                if (suc)
                {
                    SqlDataReader reader = com.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView2.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox1.Clear();
                }
            }
            conn.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_customer.Connection = conn;
            SqlCommand com = new SqlCommand("delete from Заказчик where ID_заказчика = @id", conn);
            SqlParameter p = new SqlParameter("@id", comboBox6.Text);
            com.Parameters.Add(p);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_customer.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView2.DataSource = dt;
            conn.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_customer.Connection = conn;
            SqlCommand com = new SqlCommand("update Заказчик set ФИО = @fio, Номер_телефона = @tel where ID_производства = @id", conn);
            SqlParameter p = new SqlParameter("@fio", textBox2.Text);
            SqlParameter p2 = new SqlParameter("@tel", maskedTextBox1.Text);
            SqlParameter p5 = new SqlParameter("@id", comboBox7.Text);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p5);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_customer.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView2.DataSource = dt;
            conn.Close();
        }

        public void TC1 (int id_cust, int id_prod, int quantity)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("insert into Заказы values (@id_cust, @id_prod, @sum_ord, @d, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);

            SqlParameter p = new SqlParameter("@id_cust", id_cust);
            SqlParameter p2 = new SqlParameter("@id_prod", id_prod);
            SqlParameter p4 = new SqlParameter("@d", DateTime.Now.Date);
            SqlParameter p6 = new SqlParameter("@id", id_prod);

            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com2.Parameters.Add(p6);
            conn.Open();
            bool suc = int.TryParse(textBox4.Text, out int result);
            float sum = float.Parse(com2.ExecuteScalar().ToString());
            if (suc)
            {
                float sum_prod = float.Parse(textBox4.Text.ToString()) * sum;
                SqlParameter p5 = new SqlParameter("@sum_ord", sum_prod);
                com.Parameters.Add(p5);
                com.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Неверные данные");
                textBox4.Clear();
            }
            SqlDataReader reader = com_update_order.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView3.DataSource = dt;
            conn.Close();

        }

        private void button11_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("insert into Заказы values (@id_cust, @id_prod, @sum_ord, @d, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);

            SqlParameter p = new SqlParameter("@id_cust", comboBox13.Text);
            SqlParameter p2 = new SqlParameter("@id_prod", comboBox12.Text);
            SqlParameter p4 = new SqlParameter("@d", DateTime.Now.Date);
            SqlParameter p6 = new SqlParameter("@id", comboBox12.Text);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com2.Parameters.Add(p6);
            conn.Open();
            bool suc = int.TryParse(textBox4.Text, out int result);
            float sum = float.Parse(com2.ExecuteScalar().ToString());
            if (suc)
            {
                float sum_prod = float.Parse(textBox4.Text.ToString()) * sum;
                SqlParameter p5 = new SqlParameter("@sum_ord", sum_prod);
                com.Parameters.Add(p5);
                com.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Неверные данные");
                textBox4.Clear();
            }
            SqlDataReader reader = com_update_order.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView3.DataSource = dt;
            conn.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("select * from Заказы where ID_заказа = @id;", conn);
            SqlParameter p = new SqlParameter("@id", textBox3.Text);
            com.Parameters.Add(p);
            conn.Open();
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                SqlDataReader reader = com_update_order.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView3.DataSource = dt;
            }
            else
            {
                bool suc = int.TryParse(textBox3.Text, out int result);
                if (suc)
                {
                    SqlDataReader reader = com.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView3.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox3.Clear();
                }
            }
            conn.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("delete from Заказы where ID_заказа = @id", conn);
            SqlParameter p = new SqlParameter("@id", comboBox8.Text);
            com.Parameters.Add(p);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_order.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView3.DataSource = dt;
            conn.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("update Заказы set ID_статуса = @st where ID_заказа = @id", conn);
            SqlParameter p = new SqlParameter("@st", comboBox10.Text);
            SqlParameter p5 = new SqlParameter("@id", comboBox9.Text);
            com.Parameters.Add(p);
            com.Parameters.Add(p5);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_order.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView3.DataSource = dt;
            conn.Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_users.Connection = conn;
            SqlCommand com = new SqlCommand("select * from Пользователи where ID_пользователя = @id;", conn);
            SqlCommand com2 = new SqlCommand("select * from Сотрудники where ID_пользователя in (select ID_пользователя from Пользователи where Роль = 'customer')", conn);
            SqlParameter p = new SqlParameter("@id", textBox5.Text);
            com.Parameters.Add(p);
            conn.Open();

                if (string.IsNullOrEmpty(textBox5.Text))
                {
                    SqlDataReader reader = com_update_users.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView4.DataSource = dt;
                }
                else
                {
                    bool suc = int.TryParse(textBox5.Text, out int result);
                    if (suc)
                    {
                        SqlDataReader reader = com.ExecuteReader();
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        dataGridView4.DataSource = dt;
                    }
                    else
                    {
                        MessageBox.Show("Неверные данные");
                        textBox5.Clear();
                    }
                }
            conn.Close();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_users.Connection = conn;
            SqlCommand com = new SqlCommand("delete from Пользователи where ID_пользователя = @id", conn);

            SqlParameter p = new SqlParameter("@id", comboBox11.Text);
            com.Parameters.Add(p);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_users.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView4.DataSource = dt;
            conn.Close();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_users.Connection = conn;
            SqlCommand com = new SqlCommand("update Пользователи set Пароль = @pass, Роль = @role where ID_пользователя = @id", conn);
            SqlParameter p5 = new SqlParameter("@pass", textBox7.Text);
            SqlParameter p2 = new SqlParameter("@role", comboBox15.Text);
            SqlParameter p3 = new SqlParameter("@id", comboBox14.Text);
            com.Parameters.Add(p5);
            com.Parameters.Add(p2);
            com.Parameters.Add(p3);
            conn.Open();
            if (string.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                com.ExecuteNonQuery();
                SqlDataReader reader = com_update_users.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView4.DataSource = dt;
            }
            conn.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_products.Connection = conn;
            SqlCommand com = new SqlCommand("select * from Продукты where ID_продукта = @id;", conn);
            SqlParameter p = new SqlParameter("@id", textBox8.Text);
            com.Parameters.Add(p);
            conn.Open();
            if (string.IsNullOrEmpty(textBox8.Text))
            {
                SqlDataReader reader = com_update_products.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView5.DataSource = dt;
            }
            else
            {
                bool suc = int.TryParse(textBox8.Text, out int result);
                if (suc)
                {
                    SqlDataReader reader = com.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView5.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox8.Clear();
                }
            }
            conn.Close();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_products.Connection = conn;
            SqlCommand com = new SqlCommand("insert into Продукты values (@name, @col, @pr, @coun, 'Склад 1')", conn);
            SqlParameter p = new SqlParameter("@name", textBox11.Text);
            SqlParameter p2 = new SqlParameter("@col", textBox10.Text);
            SqlParameter p4 = new SqlParameter("@pr", textBox9.Text);
            SqlParameter p6 = new SqlParameter("@coun", textBox12.Text);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com.Parameters.Add(p6);
            conn.Open();
            bool suc = int.TryParse(textBox9.Text, out int result);
            bool suc2 = int.TryParse(textBox12.Text, out int result2);
            if (suc && suc2)
            {
                com.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Неверные данные");
                textBox9.Clear();
                textBox12.Clear();
            }
            SqlDataReader reader = com_update_products.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView5.DataSource = dt;
            conn.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_products.Connection = conn;
            SqlCommand com = new SqlCommand("delete from Продукты where ID_продукта = @id", conn);

            SqlParameter p = new SqlParameter("@id", comboBox16.Text);
            com.Parameters.Add(p);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_products.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView5.DataSource = dt;
            conn.Close();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_products.Connection = conn;
            SqlCommand com = new SqlCommand("update Продукты set Название = @name, Цвет = @col, Стоимость = @pr, Количество_на_складе = @coun, Место_хранения = @pl where ID_продукта = @id", conn);
            SqlParameter p5 = new SqlParameter("@name", textBox18.Text);
            SqlParameter p2 = new SqlParameter("@col", textBox17.Text);
            SqlParameter p1 = new SqlParameter("@pr", textBox16.Text);
            SqlParameter p4 = new SqlParameter("@coun", textBox15.Text);
            SqlParameter p3 = new SqlParameter("@pl", textBox14.Text);
            SqlParameter p6 = new SqlParameter("@id", comboBox17.Text);

            com.Parameters.Add(p5);
            com.Parameters.Add(p2);
            com.Parameters.Add(p3);
            com.Parameters.Add(p6);
            com.Parameters.Add(p1);
            com.Parameters.Add(p4);
            conn.Open();
            if (string.IsNullOrEmpty(textBox18.Text) && string.IsNullOrEmpty(textBox17.Text) && string.IsNullOrEmpty(textBox16.Text) && string.IsNullOrEmpty(textBox15.Text) && string.IsNullOrEmpty(textBox14.Text))
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                bool suc = int.TryParse(textBox16.Text, out int result);
                bool suc2 = int.TryParse(textBox15.Text, out int result2);
                if (suc && suc2)
                {
                    com.ExecuteNonQuery();
                    SqlDataReader reader = com_update_products.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView5.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox16.Clear();
                    textBox15.Clear();
                }
                com.ExecuteNonQuery();
            }
            conn.Close();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox11_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox12_Enter(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_employee.Connection = conn;
            SqlCommand com = new SqlCommand("select * from Сотрудники where ID_сотрудника = @id;", conn);
            SqlParameter p = new SqlParameter("@id", textBox23.Text);
            com.Parameters.Add(p);
            conn.Open();
            if (string.IsNullOrEmpty(textBox23.Text))
            {
                SqlDataReader reader = com_update_employee.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView6.DataSource = dt;
            }
            else
            {
                bool suc = int.TryParse(textBox23.Text, out int result);
                if (suc)
                {
                    SqlDataReader reader = com.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView6.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    textBox23.Clear();
                }
            }
            conn.Close();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_employee.Connection = conn;
            SqlCommand com = new SqlCommand("insert into Сотрудники values (@fio, @d, @dab, @tel, @us)", conn);
            SqlParameter p = new SqlParameter("@fio", textBox27.Text);
            SqlParameter p2 = new SqlParameter("@d", textBox21.Text);
            SqlParameter p4 = new SqlParameter("@dab", dateTimePicker5.Value);
            SqlParameter p6 = new SqlParameter("@tel", maskedTextBox2.Text);
            SqlParameter p3 = new SqlParameter("@us", comboBox20.Text);

            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com.Parameters.Add(p6);
            com.Parameters.Add(p3);
            conn.Open();
            com.ExecuteNonQuery();
            SqlDataReader reader = com_update_employee.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView6.DataSource = dt;
            conn.Close();
        }



        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.пользователиTableAdapter.FillBy(this._Мирошниченко_419_8DataSet.Пользователи);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button20_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            com_update_employee.Connection = conn;
            SqlCommand com = new SqlCommand("update Сотрудники set ФИО = @fio, Роль = @d, Дата_рождения = @dab, Номер_телефона = @tel, ID_пользователя = @us where ID_сотрудника = @id", conn);
            SqlParameter p = new SqlParameter("@fio", textBox20.Text);
            SqlParameter p2 = new SqlParameter("@d", textBox13.Text);
            SqlParameter p4 = new SqlParameter("@dab", dateTimePicker6.Value);
            SqlParameter p6 = new SqlParameter("@tel", maskedTextBox3.Text);
            SqlParameter p5 = new SqlParameter("@id", comboBox19.Text);

            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com.Parameters.Add(p6);
            com.Parameters.Add(p5);
            conn.Open();
            if (string.IsNullOrEmpty(textBox13.Text) && string.IsNullOrEmpty(textBox20.Text))
            {
                MessageBox.Show("Заполните все поля");
            }
            else
            {
                com.ExecuteNonQuery();
                SqlDataReader reader = com_update_employee.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView6.DataSource = dt;
            }
            conn.Close();
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (role_adm == 1)
            {
                if (e.TabPageIndex == 3)
                {
                    e.Cancel = true;
                }
                if (e.TabPageIndex == 5)
                {
                    e.Cancel = true;
                }
            }
        }
    } 
}
