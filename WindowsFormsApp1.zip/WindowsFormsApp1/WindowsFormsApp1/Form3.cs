﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
        int id_cust;

        public Form3(int id)
        {
            InitializeComponent();
            id_cust = id;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.продуктыTableAdapter.Fill(this._Мирошниченко_419_8DataSet.Продукты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Продукты". При необходимости она может быть перемещена или удалена.
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("select ID_заказа, p.Название, Сумма, Дата_заказа, stat.Наименование_статуса from Заказы ord inner join Продукты p ON p.ID_продукта = ord.ID_продукта inner join Статусы_заказа stat on stat.ID_статуса = ord.ID_статуса\r\nwhere ID_заказчика = (select ID_заказчика from Заказчик where ID_пользователя = @id)", conn);
            SqlCommand com2 = new SqlCommand("select * from Продукты", conn);
            SqlCommand com3 = new SqlCommand("select ID_заказчика, ФИО, Номер_телефона, Логин, Пароль from Заказчик cust INNER JOIN Пользователи users on cust.ID_пользователя = users.ID_пользователя where users.ID_пользователя = @id", conn);
            SqlParameter p = new SqlParameter("@id", id_cust);
            SqlParameter p2 = new SqlParameter("@id", id_cust);
            com3.Parameters.Add(p2);
            com.Parameters.Add(p);
            conn.Open();
            SqlDataReader reader = com.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView1.DataSource = dt;

            SqlDataReader reader2 = com3.ExecuteReader();
            DataTable dt2 = new DataTable();
            dt2.Load(reader2);
            dataGridView3.DataSource = dt2;
            conn.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Мирошниченко_419_8DataSet.Заказы". При необходимости она может быть перемещена или удалена.

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("insert into Заказы values(@id_cust, @id_prod, @sum_prod, @date, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);
            SqlCommand com3 = new SqlCommand("select ID_заказа, p.Название, Сумма, Дата_заказа, stat.Наименование_статуса from Заказы ord inner join Продукты p ON p.ID_продукта = ord.ID_продукта inner join Статусы_заказа stat on stat.ID_статуса = ord.ID_статуса\r\nwhere ID_заказчика = (select ID_заказчика from Заказчик where ID_пользователя = @id)", conn);

            SqlParameter p = new SqlParameter("@id_cust", id_cust);
            SqlParameter p2 = new SqlParameter("@id_prod", comboBox1.Text);
            SqlParameter p6 = new SqlParameter("@id", id_cust);
            SqlParameter p4 = new SqlParameter("@id", comboBox1.Text);
            SqlParameter p5 = new SqlParameter("@date", DateTime.Now.Date);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p5);
            com2.Parameters.Add(p4);
            com3.Parameters.Add(p6);

            conn.Open();
            if (!string.IsNullOrEmpty(comboBox1.Text) && !string.IsNullOrEmpty(textBox2.Text))
            {
                float s;
                float sum = float.Parse(com2.ExecuteScalar().ToString());
                bool suc = float.TryParse(textBox2.Text.ToString(), out s);
                if (suc)
                {
                    //дописать
                    float sum_prod = float.Parse(textBox2.Text.ToString()) * sum;
                    SqlParameter p3 = new SqlParameter("@sum_prod", sum_prod);
                    com.Parameters.Add(p3);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Заказ успешно создан");
                    SqlDataReader reader = com3.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                }
            }
            else MessageBox.Show("Неверные данные");
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("delete from Заказчик where ID_пользователя = @id; delete from Пользователи where ID_пользователя = @id", conn);
            SqlParameter p = new SqlParameter("@id", id_cust);
            com.Parameters.Add(p);
            conn.Open();
            DialogResult dr = MessageBox.Show("Вы уверены, что хотите удалить аккаунт?", "Удаление", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                com.ExecuteNonQuery();
                MessageBox.Show("Аккаунт удален");
                this.Close();
            }
            conn.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("update Заказчик set Номер_телефона = @tel where ID_пользователя = @id", conn);
            SqlCommand com2 = new SqlCommand("select ID_заказчика, ФИО, Номер_телефона, Логин, Пароль from Заказчик cust INNER JOIN Пользователи users on cust.ID_пользователя = users.ID_пользователя where users.ID_пользователя = @id", conn);

            SqlParameter p = new SqlParameter("@tel", maskedTextBox1.Text);
            SqlParameter p2 = new SqlParameter("@id", id_cust);
            SqlParameter p3 = new SqlParameter("@id", id_cust);

            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com2.Parameters.Add(p3);    
            conn.Open();
            com.ExecuteNonQuery();
            com2.ExecuteNonQuery();
            SqlDataReader reader = com2.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            dataGridView3.DataSource = dt;
            conn.Close();
        }
    }
}
