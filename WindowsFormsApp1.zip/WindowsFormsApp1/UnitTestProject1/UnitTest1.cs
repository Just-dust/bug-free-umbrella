﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows.Forms;
using WindowsFormsApp1;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AdminCreateOrder()
        {
            int id_cust = 2;
            int id_prod = 1;
            string quantity = "2";
            String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com_update_order = new SqlCommand("select * from Заказы");
            com_update_order.Connection = conn;
            SqlCommand com = new SqlCommand("insert into Заказы values (@id_cust, @id_prod, @sum_ord, @d, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);
            SqlCommand com3 =  new SqlCommand("select count(*) from Заказы", conn);

            SqlParameter p = new SqlParameter("@id_cust", id_cust);
            SqlParameter p2 = new SqlParameter("@id_prod", id_prod);
            SqlParameter p4 = new SqlParameter("@d", DateTime.Now.Date);
            SqlParameter p6 = new SqlParameter("@id", id_prod);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p4);
            com2.Parameters.Add(p6);
            conn.Open();
            int orders_before = int.Parse(com3.ExecuteScalar().ToString());
            int orders_after = 0;
            bool suc = int.TryParse(quantity, out int result);
            float sum = float.Parse(com2.ExecuteScalar().ToString());
            if (suc)
            {
                float sum_prod = float.Parse(quantity) * sum;
                SqlParameter p5 = new SqlParameter("@sum_ord", sum_prod);
                com.Parameters.Add(p5);
                com.ExecuteNonQuery();
                orders_after = int.Parse(com3.ExecuteScalar().ToString());

            }
            else
            {
                MessageBox.Show("Неверные данные");
            }
            
            conn.Close();
            Assert.AreEqual(orders_before + 1, orders_after);
        }

        [TestMethod]
        public void CreateOrderCustomer()
        {
            int id_cust = 2;
            int id_prod = 1;
            string quantity = "мяу";
            bool res = false;
            String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("insert into Заказы values(@id_cust, @id_prod, @sum_prod, @date, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);
            SqlCommand com3 = new SqlCommand("select ID_заказа, p.Название, Сумма, Дата_заказа, stat.Наименование_статуса from Заказы ord inner join Продукты p ON p.ID_продукта = ord.ID_продукта inner join Статусы_заказа stat on stat.ID_статуса = ord.ID_статуса\r\nwhere ID_заказчика = (select ID_заказчика from Заказчик where ID_пользователя = @id)", conn);

            SqlParameter p = new SqlParameter("@id_cust", 2);
            SqlParameter p2 = new SqlParameter("@id_prod", id_prod);
            SqlParameter p6 = new SqlParameter("@id", 2);
            SqlParameter p4 = new SqlParameter("@id", id_prod);
            SqlParameter p5 = new SqlParameter("@date", DateTime.Now.Date);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p5);
            com2.Parameters.Add(p4);
            com3.Parameters.Add(p6);

            conn.Open();
            if (!string.IsNullOrEmpty(id_prod.ToString()) && !string.IsNullOrEmpty(quantity))
            {
                float s;
                float sum = float.Parse(com2.ExecuteScalar().ToString());
                bool suc = float.TryParse(quantity, out s);
                if (suc)
                {
                    //дописать
                    float sum_prod = float.Parse(quantity) * sum;
                    SqlParameter p3 = new SqlParameter("@sum_prod", sum_prod);
                    com.Parameters.Add(p3);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Заказ успешно создан");
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    res = true;
                }
            }
            else
            {
                MessageBox.Show("Неверные данные");
                res = true;
            }
            conn.Close();
            Assert.IsTrue(res);
        }

        [TestMethod]
        public void CreateOrderCustomerCorrect()
        {
            int id_cust = 2;
            int id_prod = 1;
            string quantity = "5";
            bool res = false;
            String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("insert into Заказы values(@id_cust, @id_prod, @sum_prod, @date, 1)", conn);
            SqlCommand com2 = new SqlCommand("select Стоимость from Продукты where ID_продукта = @id", conn);
            SqlCommand com3 = new SqlCommand("select ID_заказа, p.Название, Сумма, Дата_заказа, stat.Наименование_статуса from Заказы ord inner join Продукты p ON p.ID_продукта = ord.ID_продукта inner join Статусы_заказа stat on stat.ID_статуса = ord.ID_статуса\r\nwhere ID_заказчика = (select ID_заказчика from Заказчик where ID_пользователя = @id)", conn);

            SqlParameter p = new SqlParameter("@id_cust", 2);
            SqlParameter p2 = new SqlParameter("@id_prod", id_prod);
            SqlParameter p6 = new SqlParameter("@id", 2);
            SqlParameter p4 = new SqlParameter("@id", id_prod);
            SqlParameter p5 = new SqlParameter("@date", DateTime.Now.Date);
            com.Parameters.Add(p);
            com.Parameters.Add(p2);
            com.Parameters.Add(p5);
            com2.Parameters.Add(p4);
            com3.Parameters.Add(p6);

            conn.Open();
            if (!string.IsNullOrEmpty(id_prod.ToString()) && !string.IsNullOrEmpty(quantity))
            {
                float s;
                float sum = float.Parse(com2.ExecuteScalar().ToString());
                bool suc = float.TryParse(quantity, out s);
                if (suc)
                {
                    //дописать
                    float sum_prod = float.Parse(quantity) * sum;
                    SqlParameter p3 = new SqlParameter("@sum_prod", sum_prod);
                    com.Parameters.Add(p3);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Заказ успешно создан");
                }
                else
                {
                    MessageBox.Show("Неверные данные");
                    res = true;
                }
            }
            else
            {
                MessageBox.Show("Неверные данные");
                res = true;
            }
            conn.Close();
            Assert.IsFalse(res);
        }
        [TestMethod]
        public void IncorrectPassword()
        {
            string log = "user1";
            string pas = "nya";
            bool res = false;
            String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";

            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("select Пароль from Пользователи where Логин = @log", conn);
            SqlCommand com2 = new SqlCommand("select Роль from Пользователи where Логин = @log", conn);
            SqlCommand com3 = new SqlCommand("select ID_пользователя from Пользователи where Логин = @log;", conn);

            SqlParameter p1 = new SqlParameter("@log", log);
            SqlParameter p2 = new SqlParameter("@log", log);
            SqlParameter p3 = new SqlParameter("@log", log);

            com.Parameters.Add(p1);
            com2.Parameters.Add(p2);
            com3.Parameters.Add(p3);
            conn.Open();

            if (com.ExecuteScalar() == null)
            {
                MessageBox.Show("Неверный ввод");
                res=true;
            }
            if (com.ExecuteScalar() != null && com.ExecuteScalar().ToString() == pas)
            {
                string role = com2.ExecuteScalar().ToString();
                int role_i = 0;
                if (role == "customer")
                {
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form3 f = new Form3(id);
                    f.ShowDialog();
                    //this.Close();
                }
                if (role == "employee" || role == "admin")
                {
                    if (role == "employee")
                    {
                        role_i = 1;
                    }
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form4 f4 = new Form4(id, role_i);
                    f4.ShowDialog();
                    //this.Close();
                }
            }
            else res = true;
            conn.Close();
            Assert.IsTrue(res);
        }

        [TestMethod]
        public void EnterEmployee()
        {
            string log = "user4";
            string pas = "pass1";
            bool res = false;
            String connectionString = "Data Source=ADCLG1;Initial Catalog=Мирошниченко_419/8;Integrated Security=True;";

            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand("select Пароль from Пользователи where Логин = @log", conn);
            SqlCommand com2 = new SqlCommand("select Роль from Пользователи where Логин = @log", conn);
            SqlCommand com3 = new SqlCommand("select ID_пользователя from Пользователи where Логин = @log;", conn);

            SqlParameter p1 = new SqlParameter("@log", log);
            SqlParameter p2 = new SqlParameter("@log", log);
            SqlParameter p3 = new SqlParameter("@log", log);

            com.Parameters.Add(p1);
            com2.Parameters.Add(p2);
            com3.Parameters.Add(p3);
            conn.Open();

            if (com.ExecuteScalar() == null)
            {
                MessageBox.Show("Неверный ввод");
            }
            if (com.ExecuteScalar() != null && com.ExecuteScalar().ToString() == pas)
            {
                string role = com2.ExecuteScalar().ToString();
                int role_i = 0;
                if (role == "customer")
                {
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form3 f = new Form3(id);
                    f.ShowDialog();
                    //this.Close();
                }
                if (role == "employee" || role == "admin")
                {
                    if (role == "employee")
                    {
                        role_i = 1;
                        res = true;
                    }
                    int id = int.Parse(com3.ExecuteScalar().ToString());
                    Form4 f4 = new Form4(id, role_i);
                    f4.ShowDialog();
                    //this.Close();
                }
            }
            conn.Close();
            Assert.IsTrue(res);
        }
    }
}
